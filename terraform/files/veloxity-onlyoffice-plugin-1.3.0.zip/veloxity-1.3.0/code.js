(function (window, undefined) {
    window.Asc.plugin.init = function () {
//        this.callCommand(function () {

            // in case we need to debug
            // debugger;

            // check for version >7 where we really need the parent window
            if (window && window.parent && window.parent.params && window.parent.params._dc) {
                    window = window.parent;
            }

            // clear out the 'leavePageText' to effectively disable the editor's onbeforeunload handler
            // (the onbeforeunload handler returns this string, so making it return null instead stops the dialog
            // from appearing)
            // TI-31302
            try {
                // determine the namespace based on the editor type (document, presentation, spreadsheet)
                var namespace = window.DE || window.PE || window.SSE;
                if (namespace) {
                    // clear out the leavePageText on the namespace (assuming we found one)
                    namespace.Controllers.Main.prototype.leavePageText = null;
                }
            } catch (e) {
                // oh well
            }

            // hide the 'Co-editing Mode' button on the Collaboration tab, since we aren't going to be using it
            // TI-31303
            try {
                var style = window.document.createElement('style');
                style.innerText = '#review-changes-panel > div:nth-child(1) { display: none;}'
                    + '#review-changes-panel > div.separator.long.sharing { display: none; }';
                window.document.head.appendChild(style);
            } catch (e) {
                // oh well
            }

            // hide the 'save' button, since we'll be using our own toolbar to handle that
            // TI-31305
            try {
                var style = window.document.createElement('style');
                style.innerText = 'span#slot-btn-save { display: none; }';
                window.document.head.appendChild(style);
            } catch (e) {
                // oh well
            }

            // add a keydown handler so we can listen for Ctrl+S events
            // TI-31337
            try {
                var isMac = window.navigator && window.navigator.platform.match("Mac");
                window.document.addEventListener('keydown', function (e) {
                    var hasS = e.keyCode == 83;
                    var hasModifier = isMac ? e.metaKey : e.ctrlKey;
                    var hasBadModifier = (isMac ? e.ctrlKey : e.metaKey) || e.altKey || e.shiftKey;
                    var isRepeat = e.repeat;

                    if (hasS && hasModifier && !hasBadModifier && !isRepeat) {
                        // post a message back to the veloxClient
                        window.parent.postMessage('userRequestedSave', '*');
                    }
                });
            } catch (e) {
                // oh well
            }

            // listen for events from the velox client
            // (since we're not doing anything crazy, we don't care so much about the origin)
            try {
                window.addEventListener('message', function (e) {
                    var data = '';
                    if (typeof e.data === 'string' || e.data instanceof String) {
                        data = e.data;
                    }

                    // simulate a click on the editor's save button
                    // TI-31479
                    if ('pressSaveButton' === data) {
                        // locate the save button and click it
                        window.document.querySelector('span#slot-btn-save').firstChild.click();

                        // notify veloxity that the save button was pressed
                        window.parent.postMessage('saveButtonPressed', '*');
                    }

                    // hide the load mask for 5 seconds so that we don't see annoying brief messages
                    // TI-33502
                    if ('hideLoadMask' === data) {
                        var style = window.document.createElement('style');
                        style.innerText = '.asc-loadmask-body { display: none; }';
                        window.document.head.appendChild(style);
                        setTimeout(function () {
                            window.document.head.removeChild(style);
                        }, 5000);
                    }

                });

            } catch (e) {
                // oh well
            }

            // we want to control the way the editor automatically takes focus (as much as we can) (PR-50721)
            // flag to determine whether we want to allow focus or not
            let doFocus = true;
            // add event handler to check if we should focus
            window.document.addEventListener('blur', (e) => {
                // when clicking from editor to outside of the iframe, the relatedTarget was observed to be null
                // (note: there were other, valid cases where the relatedTarget was `undefined`, so doing strict not-equals here)
                doFocus = e.relatedTarget !== null;
            }, true);
            // we are going to assume that the user is going to click back into the editor when they want to go use
            // it, so add a pointerdown handler to detect this action and allow focus again.  This event fires before
            // the focus event.
            window.document.addEventListener('pointerdown', function (e) {
                // should fire before focus events, if user clicked into the editor; use this to reset focus flag
                doFocus = true;
            }, true);

            // tell the editor not to jump into view when clicked (so if it is partially scrolled off the screen,
            //  leave it scrolled partially off the screen when focused).
            try {
                const editorSdk = window.document.querySelector('#editor_sdk');
                const oldFocus = editorSdk.focus;
                editorSdk.focus = function () {
                    if (!doFocus) {
                        return false;
                    }
                    oldFocus.apply(this, [{ preventScroll: true }]);
                };
            } catch (e) {
                // oh well
            }

            // add a double-click handler so we can go from read-only into edit mode
            // CR-33170
            try {
                window.document.addEventListener('dblclick', function (e) {
                    // post a message back to the veloxClient
                    window.parent.postMessage('userRequestedEditMode', '*');
                });
            } catch (e) {
                // oh well
            }

            // add a click handler so that we can fire "focus" events back up to the client
            // CR-33448
            try {
                window.document.addEventListener('pointerdown', function (e) {
                    // post a message back to the veloxClient
                    window.parent.postMessage('userFocused', '*');
                }, true);
            } catch (e) {
                // oh well
            }

            // tell the editor to not steal focus upon becoming unfocused
            // this was causing the experiment to scroll back up to the office editor the first time that you
            // blurred it.
            // PR-50721
            try {
                const htmlArea = window.document.querySelector('textarea#area_id');

                const oldFocus = htmlArea.focus;
                htmlArea.focus = function () {
                    if (!doFocus) {
                        return false;
                    }
                    oldFocus.apply(this, [{ preventScroll: true }]);
                };

            } catch (e) {
                // oh well
            }

        //}, true);
    };
    window.Asc.plugin.button = function (id) {
    };
})(window, undefined);
